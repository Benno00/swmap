-- *********************************************************************************
-- *********************************************************************************
-- ** B. Jurisch® Widget Screen (Info)                                      **
-- *********************************************************************************
-- ** Autor: B. Jurisch 2023, E-Mail: benno.jurisch@gmail.de                **
-- ** 1. Das Widget kann kostenlos für den persönlichen Gebrauch verwendet werden.**
-- **    sie dürfen es nicht verteilen oder an andere weiterleiten.               **
-- **                                                                             **
-- ** 2. Widgets werden GRATIS als Geschenk von mir im https://frsky-forum.de     **
-- **    Der Firma Andreas Engel Modellbau & Technik  bereitgestell               **
-- **                                                                             **
-- ** Wenn Sie eine Spende senden möchten, um einen Teil der Entwicklungsarbeit   **
-- ** zu honorieren wäre ich Ihnen dankbar                                        **
-- ** Gerne per Paypal an benno.jurisch@dg-email.de vielen Dank                   **
-- *********************************************************************************

--**********************************************************************************
-- ** B. Jurisch® Widget Screen (Info)                                       **
--**********************************************************************************
-- ** Author: B. Jurisch 2023, email: benno.jurisch@gmail.de                **
-- ** 1. The widget is free to use for personal use.                              **
-- ** You may not distribute it or forward it to others.                          **
-- **                                                                             **
-- ** 2. Widgets will be FREE as a gift from me at https://frsky-forum.de         **
-- ** Provided by Andreas Engel Modellbau & Technik                               **
-- **                                                                             **
-- **If you would like to send a donation to be part of the development work      **
-- ** I would be grateful if you paid                                             **
-- ** Gladly via Paypal to benno.jurisch@dg-email.de thank you                    **
--**********************************************************************************
local version = "1.0"
local text={}
local schrift={{"FONT_STD",0},{"FONT_BOLD",256}, {"FONT_ITALIC",512},{"FONT_XS",1280}, {"FONT_XS_BOLD",1536},{"FONT_S",1792},{"FONT_L",2304},{"FONT_L_BOLD",2560},{"FONT_XL",2816},{"FONT_XXL",3072},{"FONT_S_BOLD",2048} }
local translations = {en="Info", de="Info"}

local function name()
    local locale = system.getLocale()
    return translations[locale] or translations["en"]
end
local function read_file_1(file)
	local fileOpen=io.open(file,"r")
	if fileOpen==nil then
		return nil, nil
	end
	local zz=0;
	while true do
		text[zz]= io.read(fileOpen,"l")
		
		if (text[zz] == nil) then break end
		text[zz]=string.sub(text[zz],1,string.len(text[zz])-1)
		
		zz=zz+1
	end
	io.close(fileOpen)
	return datum,zeit
end 
local function su_pos_1(na)
	local pos=-1
	for k,v in pairs(schrift) do 
		for k1,v1 in pairs(v) do 
			if v1==na then 
				pos=k
				break
			end
		end
	end
    return pos
end

local function paint()
	read_file_1("modelle/"..model.name()..".txt")
	local pos_y=0
	local pos_x=0
	pos=su_pos_1(text[0])
	if pos~=-1 then 
		lcd.font(schrift[pos][2])
	else
		lcd.font(FONT_STD)
	end
	local s_font_w, s_font_h = lcd.getTextSize("W")
	lcd.color(WHITE)
	for idx,key in pairs(text) do
		if text[idx]~=nil then
			lcd.drawText(pos_x,pos_y,text[idx])
		end
		pos_y=pos_y+s_font_h+1
    end
end
local function init()
   	system.registerWidget({key="BJInfo", name=name, create=create, paint=paint, })
end
return {init=init}
